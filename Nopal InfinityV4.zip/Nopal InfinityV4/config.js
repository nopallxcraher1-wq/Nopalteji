module.exports = {
  BOT_TOKEN: "TOKEN BOT",
  OWNER_ID: ["ID_OWNER"],
};
